const int = (int_variable) =>{
    return parseInt(int_variable);
}

const strtolower = (str_variable) =>{
    return str_variable.toLowerCase();
}

module.exports = {
    int,
    strtolower
}